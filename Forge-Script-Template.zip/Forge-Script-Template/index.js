const { DefaultExtractors, ForgeMusic, GuildQueueEvent } = require('@tryforge/forge.music')
const { ForgeClient, FunctionManager, LogPriority } = require('@tryforge/forgescript')
const { YoutubeiExtractor } = require('discord-player-youtubei')
const { DeezerExtractor } = require('discord-player-deezer')
const { ForgeCanvas } = require('@tryforge/forge.canvas')
const { ForgeDB } = require('@tryforge/forge.db')
const functions = require('./handlers/functions')
const { ForgeRegex } = require('forge.regex')
const { readFile } = require('fs')
const { token } = require("./config.json")

// Taken from Sora Bot.

// Error catchers.
process.on('unhandledRejection', (reason, p) => {
    console.error(reason, 'Unhandled Rejection at Promise', p)
})
.on('uncaughtException', err => {
    console.error(err, 'Uncaught Exception thrown')
    process.exit(1)
})

readFile('./constants.json', 'utf-8', (err, text) => {
    const parsed = JSON.parse(text)
    ForgeDB.variables(parsed)
})

const music = new ForgeMusic({
    connectOptions: {
        leaveOnEnd: false,
        leaveOnStop: false,
        leaveOnEmpty: false,
        disableHistory: false
    },
    events: [
        GuildQueueEvent.ConnectionDestroyed,
        GuildQueueEvent.PlayerStart,
        GuildQueueEvent.PlayerError,
        GuildQueueEvent.Connection,
        GuildQueueEvent.Disconnect,
        GuildQueueEvent.EmptyQueue,
        GuildQueueEvent.Error
    ],
    includeExtractors: DefaultExtractors
})



const client = new ForgeClient({
  extensions: [
    new ForgeDB(),
    new ForgeRegex(),
     new ForgeCanvas()
  ],

  intents: [
    "Guilds",
    "GuildMembers",
    "GuildModeration",
    "GuildEmojisAndStickers",
    "GuildIntegrations",
    "GuildWebhooks",
    "GuildInvites",
    "GuildVoiceStates",
    "GuildPresences",
    "GuildMessages",
    "GuildMessageReactions",
    "GuildMessageTyping",
    "DirectMessages",
    "DirectMessageReactions",
    "DirectMessageTyping",
    "MessageContent",
    "GuildScheduledEvents",
    "AutoModerationConfiguration",
    "AutoModerationExecution" // This intent is privileged, must be enabled in https://discord.com/developers/applications
  ],
  events: [
    "channelCreate",
    "channelDelete",
    "channelUpdate",
    "debug",
    "emojiCreate",
    "emojiDelete",
    "emojiUpdate",
    "error",
    "guildAuditLogEntryCreate",
    "guildCreate",
    "guildDelete",
    "guildMemberAdd",
    "guildMemberRemove",
    "guildMemberUpdate",
    "guildUpdate",
    "interactionCreate",
    "inviteCreate",
    "inviteDelete",
    "messageCreate",
    "messageDelete",
    "messageReactionAdd",
    "messageReactionRemove",
    "messageUpdate",
    "ready",
    "roleCreate",
    "roleDelete",
    "roleUpdate",
    "shardDisconnect",
    "shardError",
    "shardReady",
    "shardReconnecting",
    "shardResume",
    "userUpdate",
    "voiceStateUpdate"
  ],
logLevel: LogPriority.Medium,
  prefixes: [
    "!",
    "?"
  ], // Edit if needed.
  useInviteSystem: false // Set to `true if you want to use invite system.
})

// Adding custom functions.
FunctionManager.load('sora', process.cwd() + '/functions')
client.functions.add(...functions)

// Commands

client.commands.load("./commands")
console.log("[INFO] Commands has been loaded successfully!")

// Slashes

client.applicationCommands.load("./slashes")
console.log("[INFO] Slash commands are ready!")

client.commands.load('./internalCommands')
console.log("[INFO] Internal commands are ready!")


client.commands.load('./events/client')
console.log("[INFO] Client events are ready!")

client.commands.load('./interactions')
console.log("[INFO] Interactions are ready!")

music.commands.load('./events/music')
console.log("[INFO] Music events are ready!")

// Adding more sources to music service.
// music.player.extractors.register(YoutubeiExtractor, {})
// music.player.extractors.register(DeezerExtractor, { decryptionKey: process.env.DZR_DECRYPTION_KEY })


client.login(token)